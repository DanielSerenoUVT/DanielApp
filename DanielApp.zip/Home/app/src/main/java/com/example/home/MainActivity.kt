package com.example.home


import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    var monday: Button? = null
    var tuesday: Button? = null
    var wednesday: Button? = null
    var thursday: Button? = null
    var friday: Button? = null
    var saturday: Button? = null
    var sunday: Button? = null
    var add: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        monday = findViewById<View>(R.id.Monday) as Button
        tuesday = findViewById<View>(R.id.Tuesday) as Button
        wednesday = findViewById<View>(R.id.Wednesday) as Button
        thursday = findViewById<View>(R.id.Thursday) as Button
        friday = findViewById<View>(R.id.Friday) as Button
        saturday = findViewById<View>(R.id.Saturday) as Button
        sunday = findViewById<View>(R.id.Sunday) as Button
        add = findViewById<View>(R.id.Add) as Button

        monday!!.setOnClickListener(View.OnClickListener {
            val next = Intent(this@MainActivity, Monday::class.java)
            startActivity(next)
        })
        tuesday!!.setOnClickListener(View.OnClickListener {
            val next = Intent(this@MainActivity, Tuesday::class.java)
            startActivity(next)
        })
        wednesday!!.setOnClickListener(View.OnClickListener {
            val next = Intent(this@MainActivity, Wednesday::class.java)
            startActivity(next)
        })
        thursday!!.setOnClickListener(View.OnClickListener {
            val next = Intent(this@MainActivity, Thursday::class.java)
            startActivity(next)
        })
        friday!!.setOnClickListener(View.OnClickListener {
            val next = Intent(this@MainActivity, Friday::class.java)
            startActivity(next)
        })
        saturday!!.setOnClickListener(View.OnClickListener {
            val next = Intent(this@MainActivity, Saturday::class.java)
            startActivity(next)
        })
        sunday!!.setOnClickListener(View.OnClickListener {
            val next = Intent(this@MainActivity, Sunday::class.java)
            startActivity(next)
        })
        add!!.setOnClickListener(View.OnClickListener {
            val next = Intent(this@MainActivity, Add
            ::class.java)
            startActivity(next)
        })

    }
    //intent
}