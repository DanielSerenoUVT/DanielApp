package com.example.home

import android.app.AlertDialog
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity


open class Sunday : AppCompatActivity(), View.OnClickListener {

    var hour= ""
    lateinit var db: SQLiteDatabase
    var back: Button? = null
    var view: Button? = null
    var delete: Button? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sunday)

        db = openOrCreateDatabase("meals", MODE_PRIVATE, null)

        db.execSQL("CREATE TABLE IF NOT EXISTS meals (day VARCHAR,hour VARCHAR, name VARCHAR);")

        val list= resources.getStringArray(R.array.hours)
        back = findViewById<View>(R.id.back) as Button
        back!!.setOnClickListener(this)
        view= findViewById<View>(R.id.view) as Button
        view!!.setOnClickListener(this)
        delete= findViewById<View>(R.id.delete) as Button
        delete!!.setOnClickListener(this)
        var hours: Spinner= findViewById<Spinner>(R.id.spinner2)
        val adapter= ArrayAdapter.createFromResource(this, R.array.hours, R.layout.support_simple_spinner_dropdown_item)
        hours.adapter= adapter

        hours.onItemSelectedListener= object:
            AdapterView.OnItemClickListener, AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                hour= list[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemClick(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {

            }

        }

    }

    override
    fun onClick(v: View) {

        if (v === delete) {
            val c = db.rawQuery("SELECT * FROM meals WHERE hour='" + hour + "'", null)
            if (c.moveToFirst()) {
                db.execSQL("DELETE FROM meals WHERE hour='" + hour + "'")
                showMessage(
                    "Success",
                    "The " + hour.toUpperCase() + " was deleted!"
                )
            } else {
                showMessage("Error", "")
            }
        }
        if (v === view) {
            val c = db.rawQuery("SELECT * FROM meals WHERE hour='" + hour + "'", null)
            //showMessage(c.getString(2), c.getString(3));
            if (c.moveToFirst()) {
                showMessage(
                    "The " + hour.toUpperCase() + " of " +  c.getString(1) + " is: ",
                    c.getString(2)
                )
            } else {
                showMessage("Error", "Invalid Enroll Number")
            }
        }
        if (v === back) {
            back!!.setOnClickListener(View.OnClickListener {
                val next = Intent(this@Sunday, MainActivity::class.java)
                startActivity(next)
            })
        }
    }

    fun showMessage(title: String?, message: String?) {
        val builder = AlertDialog.Builder(this)
        builder.setCancelable(true)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.show()
    }

}
