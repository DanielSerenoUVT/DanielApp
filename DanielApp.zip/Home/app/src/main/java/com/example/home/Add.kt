package com.example.home

import android.app.AlertDialog
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class Add : AppCompatActivity(), View.OnClickListener {

    var hour= ""
    var day= ""
    var back: Button? = null
    var add: Button? = null
    var Name: EditText? = null
    lateinit var db: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        db = openOrCreateDatabase("meals", MODE_PRIVATE, null)
        db.execSQL("CREATE TABLE IF NOT EXISTS meals (day VARCHAR,hour VARCHAR, name VARCHAR);")

        back = findViewById<View>(R.id.back) as Button
        back!!.setOnClickListener(this)
        add = findViewById<View>(R.id.view) as Button
        add!!.setOnClickListener(this)

        Name = findViewById<View>(R.id.Meal) as EditText

        val list= resources.getStringArray(R.array.hours)
        var hours: Spinner = findViewById<Spinner>(R.id.Hour)
        val adapter= ArrayAdapter.createFromResource(this, R.array.hours, R.layout.support_simple_spinner_dropdown_item)
        hours.adapter= adapter

        hours.onItemSelectedListener= object:
            AdapterView.OnItemClickListener, AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                hour= list[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemClick(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {

            }
        }
        val list2= resources.getStringArray(R.array.days)
        var days: Spinner = findViewById<Spinner>(R.id.Day)
        val adapter2= ArrayAdapter.createFromResource(this, R.array.days, R.layout.support_simple_spinner_dropdown_item)
        days.adapter= adapter2
        days.onItemSelectedListener= object:
            AdapterView.OnItemClickListener, AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                day= list2[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemClick(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {

            }
        }
    }

    override fun onClick(v: View?) {
        if (v === back) {
            back!!.setOnClickListener(View.OnClickListener {
                val next = Intent(this@Add, MainActivity::class.java)
                startActivity(next)
            })
        }

        if (v === add) {
                val c = db.rawQuery("SELECT * FROM meals ", null)
                if (Name!!.text.toString().isEmpty()) {
                    showMessage("Error", "Please enter all data")
                } else {
                    db.execSQL("INSERT INTO meals VALUES('" + day + "','" + hour + "','" + Name!!.text + "');")
                    showMessage("Success", "Record added")
                    clearText()
                }
            }
    }

    fun showMessage(title: String?, message: String?) {
        val builder = AlertDialog.Builder(this)
        builder.setCancelable(true)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.show()
    }

    fun clearText() {
        Name!!.setText("")
    }
}